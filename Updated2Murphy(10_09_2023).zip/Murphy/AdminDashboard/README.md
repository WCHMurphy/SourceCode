# E-LEARNING-APPLICATION-V1.0:

dashboard simple pour gestion des course,students,payments...

## lien de vedeo in youtube :
https://www.youtube.com/watch?v=bDfINmhpzd0

## technologie utiliser
  ### front end :
  html,css,framework bootstrap .
  ### back end:
  php,sql server.

## les pages du site:
  ### sign in: 
  email ,password:
  ### home: 
  statistique: nombre des course ,user,students,payments
  ### students list: 
  les informations des students: img,username,email...
  ### payments:
  les informations de payments:
