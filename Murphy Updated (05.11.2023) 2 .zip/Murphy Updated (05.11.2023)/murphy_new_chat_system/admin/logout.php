<?php
require("config/func.php");require("config/value.php");
destroyAllCookies();header("location: $_LOGIN_FILE");exit;