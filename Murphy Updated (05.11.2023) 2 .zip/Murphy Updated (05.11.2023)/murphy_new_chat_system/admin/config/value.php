<?php
$limit_create_mode 		= true; //turn on or off limit create room
$limit_create_count 	= 4; //count room members can create

/** redirect or filename **/
$_CHAT_FILE		= "chat.php";
$_HOME_FILE	 	= "home.php";
$_LOGIN_FILE	= "login.php";
$_LOGOUT_FILE	= "logout.php";