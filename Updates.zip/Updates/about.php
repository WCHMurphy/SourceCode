<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="about">
      <h1>About Us</h1>
      <p>WCH Solutions, drawing on the combined one hundred and thirty years of relevant experience of the four senior team members, have developed Project Oversight Best Practices which when linked with our independence, delivers real value to a Client's project journey.</p>
      <p>The WCH Solutions approach provides our clients with access to capable senior team members at appropriate stages in the project, to assist with decision making and provides an acceptable level of comfort that a governance process exists and is making sure things do not fall through the cracks.</p>
    </section>
  </div>
</body>
</html>
