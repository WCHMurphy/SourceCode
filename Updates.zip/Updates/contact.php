<?php include_once "header.php"; ?>
<body>
  <div class="wrapper">
    <section class="contact">
      <h1>Contact Us</h1>
      <p>For any inquiries or support, please fill out the form below or reach us through the provided contact details.</p>
      <form action="#" method="POST">
        <div class="field">
          <label>Your Name</label>
          <input type="text" name="name" placeholder="Enter your name" required>
        </div>

        <div class="field">
          <label>Email Address</label>
          <input type="email" name="email" placeholder="Enter your email" required>
        </div>

        <div class="field">
          <label>Message</label>
          <textarea name="message" placeholder="Enter your message" required></textarea>
        </div>

        <div class="field button">
          <input type="submit" name="submit" value="Send Message">
        </div>
      </form>
    </section>
  </div>
</body>
</html>
