<!DOCTYPE html>
<html>
<head>
    <title>My Website - About Us</title>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
    <header>
        <h1>MURPHY</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Murphy</a></li>
            </ul>
        </nav>
    </header>
    
    <section>
        <h1>About Murphy Game</h1>
        <p>Murphy is a web and mobile game application that challenges players to work together to solve problems based on clues provided on cards. Each team is given 28 cards with clues, and the team that solves the problem first wins. Murphy is designed to promote teamwork and problem-solving skills, while providing an entertaining and engaging experience for players of all ages.</p>
        
        <h2>Our Team</h2>
        <p>Our team is composed of experienced game developers and designers who are passionate about creating engaging and innovative games. We believe that games can be more than just entertainment – they can also be tools for education and personal development.</p>
        
        <h3>Meet Our Team Members:</h3>
        <ul>
            <li>Vuyo - Lead Developer</li>
            <li>Dumo - Lead Designer</li>
            <li>Gideon - Programmer</li>
            <li>Sally - Designer</li>
            <li>Derek - Lead Designer</li>
        </ul>
        
        
    </section>

      <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #ffff;
    }
    
    /*.container {
      max-width: 800px;
      margin: 0 auto;
      padding: 40px;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);*/
    }
    
    h1 {
      font-size: 36px;
      color: #333;
      text-align: center;
    }
    
    p {
      font-size: 18px;
      color: #666;
      line-height: 1.6;
    }
    
    .highlight {
      color: #ff6600;
      font-weight: bold;
    }
    
    .team {
      display: flex;
      justify-content: space-between;
      margin-top: 40px;
    }
    
    .member {
      flex-basis: 30%;
      text-align: center;
    }
    
    .member img {
      width: 100%;
      border-radius: 50%;
      margin-bottom: 10px;
    }
    
    .member h3 {
      font-size: 24px;
      color: #333;
    }
    
    .member p {
      font-size: 16px;
      color: #666;
    }
  </style>
</body>
</html>
