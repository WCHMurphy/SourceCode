<!DOCTYPE html>
<html>
<head>
    <title>My Website - Contact</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>MURPHY</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Gameplay</a></li>
            </ul>
        </nav>
    </header>
    
    <section>
        <h2>Contact</h2>
        <p>This is the contact page of my website.</p>
    </section>
</body>
</html>
